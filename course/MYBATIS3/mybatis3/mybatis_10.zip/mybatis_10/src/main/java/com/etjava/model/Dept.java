package com.etjava.model;

import lombok.Data;
import lombok.ToString;

import java.util.List;
@Data
@ToString
public class Dept {
    private Integer id;
    private String deptName;
    private List<User> userList;
}