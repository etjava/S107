package com.etjava.test;

import com.etjava.mappers.StudentMappers;
import org.apache.ibatis.session.SqlSession;

import com.etjava.model.Student;
import com.etjava.util.SqlSessionFactoryUtil;

public class StudentTest {

    public static void main(String[] args) {
        // 获取SqlSession
        SqlSession sqlSession = SqlSessionFactoryUtil.openSession();
        // 获取Mapper mybatis帮我们做的映射接口
        StudentMappers studentMapper = sqlSession.getMapper(StudentMappers.class);
        // 添加数据到数据库
        Student stu = new Student("Jerry",28);
        int res = studentMapper.add(stu);
        // 执行完成需要手动提交事务
        sqlSession.commit();
        System.out.println(res);
    }
}
