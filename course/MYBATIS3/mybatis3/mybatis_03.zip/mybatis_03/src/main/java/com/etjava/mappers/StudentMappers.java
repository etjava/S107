package com.etjava.mappers;

import com.etjava.model.Student;

/**
 * Student Mapper接口
 */
public interface StudentMappers {
    /**
     * 添加学生信息
     * @param stu
     * @return
     */
    public int add(Student stu);

    /**
     * 修改学生信息
     * @param stu
     * @return
     */
    public int update(Student stu);

    /**
     * 删除学生信息
     * @param id
     * @return
     */
    public int delete(Integer id);
}
