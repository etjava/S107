
CREATE TABLE `t_book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookName` varbinary(32) DEFAULT NULL COMMENT '书籍名称',
  `price` double DEFAULT NULL COMMENT '单价',
  `releaseDate` datetime DEFAULT NULL COMMENT '出版日期',
  `typeId` int(11) DEFAULT NULL COMMENT '所属类别',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;



insert  into `t_book`(`id`,`bookName`,`price`,`releaseDate`,`typeId`) values (1,'Think in Java',99.99,'0000-00-00 00:00:00',1),(2,'C语言设计之美',99.8,'0000-00-00 00:00:00',1),(3,'上林赋',9.99,NULL,2),(4,'三毛',2,NULL,3),(5,'邪骨咒',3,NULL,3);



CREATE TABLE `t_booktype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typeName` varchar(32) DEFAULT NULL,
  `orderNum` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;



insert  into `t_booktype`(`id`,`typeName`,`orderNum`) values (1,'编程',1),(2,'文学',2),(3,'恐怖',3);


