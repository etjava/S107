package com.etjava.mappers;

import com.etjava.model.Student;

/**
 * Student Mapper接口
 */
public interface StudentMappers {
    /**
     * 添加学生信息
     * @param stu
     * @return
     */
    public int add(Student stu);
}
