package com.etjava.model;

public class Teacher {
    private Integer id;
    private String teaName;
    private Integer teaAge;
    private String curriculum;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTeaName() {
        return teaName;
    }

    public void setTeaName(String teaName) {
        this.teaName = teaName;
    }

    public Integer getTeaAge() {
        return teaAge;
    }

    public void setTeaAge(Integer teaAge) {
        this.teaAge = teaAge;
    }

    public String getCurriculum() {
        return curriculum;
    }

    public void setCurriculum(String curriculum) {
        this.curriculum = curriculum;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "id=" + id +
                ", teaName='" + teaName + '\'' +
                ", teaAge=" + teaAge +
                ", curriculum='" + curriculum + '\'' +
                '}';
    }
}