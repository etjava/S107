package com.etjava.mappers;

import com.etjava.model.Grade;

public interface GradeMapper {
    // 根据ID查询年级
    Grade findById(Integer id);
}
