package com.etjava.service;

import com.etjava.mappers.TeacherMapper;
import com.etjava.model.Teacher;
import com.etjava.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

public class TeacherTest {
    private static Logger logger = Logger.getLogger(TeacherTest.class);
    // 定义SQLSession 用来操作数据库
    SqlSession sqlSession = null;
    // 获取Student映射文件
    TeacherMapper teacherMapper = null;
    // 测试方法执行之前
    @Before
    public void setUp(){
        sqlSession = SqlSessionFactoryUtil.openSession();
        teacherMapper = sqlSession.getMapper(TeacherMapper.class);
    }

    // 测试方法执行之后
    @After
    public void tearDown(){
        sqlSession.close();
    }

    @Test
    public void testFind(){
        Map<String,Object> map = new HashMap<>();
        map.put("teaName","Jerry");
        List<Teacher> list = teacherMapper.find(map);
        for (Teacher teacher : list) {
            System.out.println(teacher);
        }
    }

    @Test
    public void testAdd(){
        Teacher teacher = new Teacher();
        teacher.setId(1);
        teacher.setTeaAge(22);
        teacher.setTeaName("Tom3");
        teacher.setRemark("这是一个很长的文本内容...........");
        byte[] pic = null;
        try (FileInputStream fis = new FileInputStream("d:/a.jpg");){
            pic = new byte[fis.available()];// available 文件的长度
            fis.read(pic);// 将文件存放到字节数组中
        }catch (Exception e){
            e.printStackTrace();
        }
        teacher.setPic(pic);
        int res = teacherMapper.addTeacher(teacher);
        System.out.println(res);
        sqlSession.commit();
    }








}
