package com.etjava.service;

import com.etjava.mappers.TeacherMapper;
import com.etjava.mappers.UserMapper;
import com.etjava.model.Teacher;
import com.etjava.model.User;
import com.etjava.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserTest {
    private static Logger logger = Logger.getLogger(UserTest.class);
    // 定义SQLSession 用来操作数据库
    SqlSession sqlSession = null;
    // 获取Student映射文件
    UserMapper userMapper = null;
    // 测试方法执行之前
    @Before
    public void setUp(){
        sqlSession = SqlSessionFactoryUtil.openSession();
        userMapper = sqlSession.getMapper(UserMapper.class);
    }

    // 测试方法执行之后
    @After
    public void tearDown(){
        sqlSession.close();
    }

    @Test
    public void testAdd(){
        User u = new User();
        u.setName("Tom");
        u.setAge(16);
        Integer res = userMapper.add(u);
        System.out.println(res);
        sqlSession.commit();
    }

    @Test
    public void testUpdate(){
        User u = new User();
        u.setName("Judy3");
        u.setAge(16);
        u.setId(6);
        Integer res = userMapper.update(u);
        System.out.println(res);
        sqlSession.commit();
    }

    @Test
    public void testDelete(){
        Integer res = userMapper.delete(4);
        System.out.println(res);
        sqlSession.commit();
    }

    @Test
    public void testQuery(){
        User user = userMapper.findById(1);
        System.out.println(user);
    }

    @Test
    public void testQuery2(){
        List<User> list = userMapper.list();
        for (User user2 : list) {
            System.out.println(user2);
        }
    }

    @Test
    public void testQuery3(){
        List<User> u = userMapper.findUserWithAddress();
        for (User user2 : u) {
            System.out.println(user2);
        }
    }
}
