package com.etjava.service;

import com.etjava.mappers.StudentMappers;
import com.etjava.model.Student;
import com.etjava.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

// 测试SQL映射器
public class TestSQLMapping {
    private static Logger logger = Logger.getLogger(TestSQLMapping.class);
    // 定义SQLSession 用来操作数据库
    SqlSession sqlSession = null;
    // 获取Student映射文件
    StudentMappers studentMapper = null;
    // 测试方法执行之前
    @Before
    public void setUp(){
        sqlSession = SqlSessionFactoryUtil.openSession();
        studentMapper = sqlSession.getMapper(StudentMappers.class);
    }

    // 测试方法执行之后
    @After
    public void tearDown(){
        sqlSession.close();
    }

    // 添加学生
    @Test
    public void teseAdd(){
        int res = studentMapper.add(new Student("Jerry", 13));
        if(res>0){
            logger.info("添加成功");
        }else{
            logger.info("添加失败");
        }
    }

    // 修改学生信息
    @Test
    public void teseUpdate(){
        int res = studentMapper.update(new Student(1, "Andy", 12));
        if(res>0){
            logger.info("修改成功");
        }else{
            logger.info("修改失败");
        }
    }
    // 删除学生信息
    @Test
    public void testDelete(){
        int res = studentMapper.delete(2);
        if(res>0){
            logger.info("删除成功");
        }else{
            logger.info("删除失败");
        }
    }

    // 根据ID查询学生信息
    @Test
    public void testFindById(){
        Student stu = studentMapper.findById(1);
        System.out.println(stu);
    }

    // 根据姓名模糊匹配学生信息
    @Test
    public void testFindByName(){
        List<Student> stuList = studentMapper.findByName("Jerry");
        System.out.println(stuList.size());
    }

    // 查询全部学生信息 带分页
    @Test
    public void testFindAll(){
        Map<String,Object> map = new HashMap<>();
        map.put("start",0);
        map.put("size",2);
        List<Student> stuList = studentMapper.findAll(map);
        System.out.println(stuList.size());
    }

    @Test
    public void testFindStudentWithAddress(){
        Student stu = studentMapper.findStudentWithAddress(1);
        System.out.println(stu.getStuName()+"==="+stu.getAddress().getSheng());
    }
}