package com.etjava.service;

import com.etjava.mappers.DeptMapper;
import com.etjava.model.Dept;
import com.etjava.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class DeptTest {
    private static Logger logger = Logger.getLogger(DeptTest.class);
    // 定义SQLSession 用来操作数据库
    SqlSession sqlSession = null;
    // 获取Student映射文件
    DeptMapper deptMapper = null;
    // 测试方法执行之前
    @Before
    public void setUp(){
        sqlSession = SqlSessionFactoryUtil.openSession();
        deptMapper = sqlSession.getMapper(DeptMapper.class);
    }

    // 测试方法执行之后
    @After
    public void tearDown(){
        sqlSession.close();
    }


    @Test
    public void testQuery3(){
        Dept d = deptMapper.findById2(1);
        System.out.println(d);
    }
}