package com.etjava.service;

import com.etjava.mappers.TeacherMapper;
import com.etjava.model.Teacher;
import com.etjava.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherTest {
    private static Logger logger = Logger.getLogger(TeacherTest.class);
    // 定义SQLSession 用来操作数据库
    SqlSession sqlSession = null;
    // 获取Student映射文件
    TeacherMapper teacherMapper = null;
    // 测试方法执行之前
    @Before
    public void setUp(){
        sqlSession = SqlSessionFactoryUtil.openSession();
        teacherMapper = sqlSession.getMapper(TeacherMapper.class);
    }

    // 测试方法执行之后
    @After
    public void tearDown(){
        sqlSession.close();
    }

    // 测试多条件查询 if判断
    @Test
    public void testFind(){
        Map<String,Object> map = new HashMap<>();
        //map.put("teaName","Tom");
        List<Teacher> list = teacherMapper.find(map);
        for (Teacher teacher : list) {
            System.out.println(teacher);
        }
    }

    /*
    choose when otherwhise
    多条件选择
     */
    @Test
    public void testFind2(){
        Map<String,Object> map = new HashMap<>();
        map.put("searchBy","name");
        map.put("teaName","Tom");
        List<Teacher> list = teacherMapper.find2(map);
        for (Teacher teacher : list) {
            System.out.println(teacher);
        }
    }
}
