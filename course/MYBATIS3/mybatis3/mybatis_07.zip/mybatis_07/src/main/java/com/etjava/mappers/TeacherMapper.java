package com.etjava.mappers;

import com.etjava.model.Teacher;

import java.util.List;
import java.util.Map;

public interface TeacherMapper {

    List<Teacher> find(Map<String,Object> map);

    List<Teacher> find2(Map<String,Object> map);
}
