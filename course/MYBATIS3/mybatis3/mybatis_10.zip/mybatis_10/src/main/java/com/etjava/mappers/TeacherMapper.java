package com.etjava.mappers;

import com.etjava.model.Teacher;
import org.apache.ibatis.session.RowBounds;

import java.util.List;
import java.util.Map;

public interface TeacherMapper {

    List<Teacher> find(Map<String,Object> map);

    int addTeacher(Teacher teacher);
}
