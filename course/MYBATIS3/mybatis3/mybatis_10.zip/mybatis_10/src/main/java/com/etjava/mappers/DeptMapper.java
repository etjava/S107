package com.etjava.mappers;

import com.etjava.model.Dept;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

public interface DeptMapper {
    @Select("select * from t_dept where id=#{id}")
    Dept findById(Integer id);

    @Select("select * from t_dept where id=#{id}")
    @Results(
            {
                    @Result(id = true,column = "id",property = "id"),
                    @Result(column = "deptName",property = "deptName"),
                    // 关联查询 需要带入当前表的主键 到User表中根据外键查询
                    @Result(column = "id",property = "userList"
                            ,many = @Many(select = "com.etjava.mappers.UserMapper.findUserWithDeptId"))
            }
    )
    Dept findById2(Integer id);
}